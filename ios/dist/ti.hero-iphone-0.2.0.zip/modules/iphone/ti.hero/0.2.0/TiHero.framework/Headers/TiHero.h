//
//  TiHero.h
//  ti.hero
//
//  Created by Your Name
//  Copyright (c) 2018 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiHero.
FOUNDATION_EXPORT double TiHeroVersionNumber;

//! Project version string for TiHero.
FOUNDATION_EXPORT const unsigned char TiHeroVersionString[];

#import "TiHeroModuleAssets.h"
